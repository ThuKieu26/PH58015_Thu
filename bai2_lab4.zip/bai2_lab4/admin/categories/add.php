<h2>Thêm danh mục</h2>
<form action="" method="post">
    <p>Nhập tên danh mục</p>
    <input type="text" required name="name"><br>
    <button type="submit">Thêm</button>
</form>