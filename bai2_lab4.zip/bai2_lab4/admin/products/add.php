<h2>Thêm sản phẩm</h2>
<form method="POST">
    <p>Nhập tên sản phẩm</p>
    <input name="name" required><br>
    <p>Nhập giá</p>
    <input name="price" required><br>
    <p>Mô tả sản phẩm</p>
    <textarea name="description"></textarea><br>
    <select name="category_id">
        <?php foreach ($categories as $c): ?>
            <option value="<?= $c['id'] ?>"><?= $c['name'] ?></option>
        <?php endforeach; ?>
    </select><br>
    <button>Thêm</button>
</form>