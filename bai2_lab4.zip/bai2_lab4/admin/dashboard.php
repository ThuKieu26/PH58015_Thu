<h1>Quản trị web</h1>
<ul>
    <li><a href="index.php?pg=list_category">Quản lý danh mục</a></li>
    <li><a href="index.php?pg=list_product">Quản lý sản phẩm</a></li>
</ul>