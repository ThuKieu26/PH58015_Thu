<?php
class HomeController
{
    public function view() {
        include "views/home.php";
    }
}