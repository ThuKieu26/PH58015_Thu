<h1 style="margin: 10px 600px;">Đăng nhập</h1>
<form action="" style="margin: 10px 600px;">
    <input type="text" placeholder="Tên người dùng"><br>
    <input type="password" placeholder="Mật khẩu"><br>
    <button>Đăng nhập</button>
</form>