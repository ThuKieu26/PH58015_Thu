<h1 style="margin: 10px 800px;">Hello</h1>
<p style="margin: 10px 650px;">Chào mừng đến với cửa hàng của chúng tôi!</p>
<div class="banner" style="margin-left: 600px;">
    <img src="public/image/spchitiet.jpeg" width="560px" height="260px"  >
</div>
<a href="index.php?pg=products" style="margin-left: 700px;">Xem sản phẩm</a>
<a href="index.php?pg=admin" style="display: inline-block; padding: 10px; border-radius: 5px;">Vào trang quản trị</a>
<a href="index.php?pg=login" style="margin-right: 10px;"> Đăng nhập</a>
<a href="index.php?pg=register"> Đăng ký</a>