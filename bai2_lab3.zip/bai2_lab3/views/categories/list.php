<h1>Danh mục</h1>
<ul>
    <?php foreach($categories as $item){
    ?>
    <li><?= $item["name"] ?></li>
    <?php
    } ?>
</ul>