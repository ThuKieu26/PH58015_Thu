<h1>Danh sách sản phẩm</h1>
<table border="1">
    <tr>
        <th>Tên</th>
        <th>Giá</th>
        <th>Danh mục</th>
    </tr>
    <?php foreach($products as $sp){
    ?>
    <tr>
        <td><?= $sp["name"] ?></td>
        <td><?=number_format($sp["price"])?>đ</td>
        <td><?= $sp["category_name"] ?></td>
    </tr>
    <?php } ?>
</ul>
</table>
    