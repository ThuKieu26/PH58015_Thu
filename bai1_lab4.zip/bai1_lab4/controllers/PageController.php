<?php
class PageController {
    public function introduce() { include 'views/introduce.php'; }
    public function contact() { include 'views/contact.php'; }
    public function login() { include 'views/login.php'; }
    public function register() { include 'views/register.php'; }
}
