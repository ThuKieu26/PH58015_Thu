<h1>Quản trị web</h1>
<ul>
    <li><a href="index.php?pg=categories">Quản lý danh mục</a></li>
    <li><a href="index.php?pg=products">Xem sản phẩm</a></li>
</ul>