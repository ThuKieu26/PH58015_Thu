<h2>Sửa danh mục</h2>
<form action="" method="post">
    <p>Nhập tên danh mục</p>
    <input type="text" required name="name" value="<?=$category['name'] ?>"><br>
    <button type="submit">Cập nhật</button>
</form>