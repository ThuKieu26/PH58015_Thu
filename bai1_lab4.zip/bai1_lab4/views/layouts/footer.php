<hr>
<footer style="margin-left: 100px;">
    <img src="public/image/footer.png" width="1500px" height="400px">
</footer>
</div>
</body>
</html>