<h1 style="margin: 10px 600px;">Sản phẩm</h1>
<?php foreach ($products as $p): ?>
    <div  style="margin: 10px 500px; border: 1px solid lightgray; padding: 10px;">
        <h3><?= $p['name'] ?> - giá <?= number_format($p['price']) ?>đ</h3>
        <p>Danh mục: <?= $p['category_name'] ?></p>
        <a href="index.php?pg=product_detail&id=<?= $p['id'] ?>">Xem chi tiết</a>
    </div>
    
<?php endforeach; ?>
