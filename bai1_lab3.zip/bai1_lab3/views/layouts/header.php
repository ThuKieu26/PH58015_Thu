<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>
<div class="container">
    <header>
        <img src="public/image/logo.jpg" width="60px" height="60px">
        <nav>
            <a href="index.php">Trang chủ</a>
            <a href="index.php?pg=products">Sản phẩm</a>
            <a href="index.php?pg=login">Đăng nhập</a>
            <a href="index.php?pg=register">Đăng ký</a>
            <a href="index.php?pg=introduce">Giới thiệu</a>
            <a href="index.php?pg=contact">Liên hệ</a>
        </nav>
    </header>
<hr>