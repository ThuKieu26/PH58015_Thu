<h1 style="margin: 10px 700px;">Liên hệ</h1>
<p style="margin: 10px 600px;">GỌI MUA HÀNG( 08:30-21:30 ) 036 866 3456</p>
<p style="margin: 10px 600px;">Tất cả các ngày trong tuần</p><br><br>
<p style="margin: 10px 600px;">GÓP Ý, KHIẾU NẠI ( 08:30-20:30 ) 036 866 3456</p>
<p style="margin: 10px 600px;">Các ngày trong tuần ( trừ ngày lễ )</p><br>
