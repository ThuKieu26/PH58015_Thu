<h1 style="margin: 10px 600px;">Sản phẩm</h1>
<ul>
<?php foreach ($products as $p): ?>
    <li style="list-style-type: none; margin: 10px 600px;">
        <a href="index.php?pg=product-detail&id=<?= $p['id'] ?>" style="text-decoration: none; color: black">
            <?= $p['name'] ?> giá <?= number_format($p['price']) ?>đ
        </a>
    </li>
<?php endforeach; ?>
</ul>
