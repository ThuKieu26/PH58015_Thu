<h1  style="margin: 10px 700px;">Chi tiết sản phẩm</h1>
<?php if ($product): ?>
    <p style="margin: 10px 600px;"><strong>Tên:</strong> <?= $product['name'] ?></p><br>
    <p style="margin: 10px 600px;"><strong>Màu:</strong> <?= $product['color'] ?></p><br>
    <p style="margin: 10px 600px;"><strong>Giá:</strong> <?= number_format($product['price']) ?>đ</p><br>
    <p style="margin: 10px 600px;"><strong>Kho:</strong> <?= $product['quantity'] ?></p><br>
<?php else: ?>
    <p>Sản phẩm không tồn tại.</p>
<?php endif; ?>
