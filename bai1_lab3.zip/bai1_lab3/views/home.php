<h1 style="margin: 10px 800px;">Hello</h1>
<p style="margin: 10px 650px;">Chào mừng đến với cửa hàng của chúng tôi!</p>
<div class="banner" style="margin-left: 600px;">
    <img src="public/image/spchitiet.jpeg" width="560px" height="260px"  >
</div>