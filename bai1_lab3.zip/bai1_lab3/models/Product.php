<?php
    function getAllProducts(){
        return [
            ["id"=> 1, "name" => "Túi đeo chéo", "color"=>"đen", "price"=> 1200000, "quantity" => 5],
            ["id"=> 2, "name" => "Túi đeo vai", "color"=>"trắng", "price"=> 1400000, "quantity" => 15],
            ["id"=> 3, "name" => "Túi cầm tay", "color"=>"đen", "price"=> 1800000, "quantity" => 6],
            ["id"=> 4, "name" => "Túi tote", "color"=>"trắng", "price"=> 1200000, "quantity" => 9],
        ];
    }
    function getProductById($id) {
    $products = getAllProducts();
    foreach ($products as $p) {
        if ($p['id'] == $id) return $p;
    }
    return null;
    }
