<?php
include_once "views/layouts/header.php";

if (isset($_GET['pg'])) {
    $pg = $_GET['pg'];
    switch ($pg) {
        case 'products':
            include_once "controllers/ProductController.php";
            $ctrl = new ProductController();
            $ctrl->set_view("list");
            $ctrl->view();
            break;

        case 'product-detail':
            include_once "controllers/ProductController.php";
            $ctrl = new ProductController();
            $ctrl->set_view("detail");
            $ctrl->view();
            break;

        case 'register':
            include_once "controllers/PageController.php";
            $ctrl = new PageController();
            $ctrl->set_view("dndk/register");
            $ctrl->view();
            break;

        case 'login':
            include_once "controllers/PageController.php";
            $ctrl = new PageController();
            $ctrl->set_view("dndk/login");
            $ctrl->view();
            break;

        case 'introduce':
            include_once "controllers/PageController.php";
            $ctrl = new PageController();
            $ctrl->set_view("introduce");
            $ctrl->view();
            break;

        case 'contact':
            include_once "controllers/PageController.php";
            $ctrl = new PageController();
            $ctrl->set_view("contact");
            $ctrl->view();
            break;

        default:
            include_once "controllers/HomeController.php";
            $ctrl = new HomeController();
            $ctrl->set_view("home");
            $ctrl->view();
            break;
    }
} else {
    include_once "controllers/HomeController.php";
    $ctrl = new HomeController();
    $ctrl->set_view("home");
    $ctrl->view();
}

include_once "views/layouts/footer.php";
